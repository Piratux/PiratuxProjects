#include "Menu.h"

void init_menu(Menu* menu)
{
	menu->options = 5;
    menu->show_option = 0;
    menu->texture_enum_offset = 4; //if TextureID enum changes, this needs to change too
}
void draw_menu(Screen* screen, Texture* tex, Menu* menu)
{
	float shade = -0.5f;
	int show_idx = menu->texture_enum_offset + menu->show_option;
	
	draw_image(screen, &tex[MenuScreenIMG], tex[MenuScreenIMG].pos, 0.0f);
	
	// upper menu option
	if(mouse_in_region(screen, 8, 23, 17, 21))
	{
		draw_image(screen, &tex[SelectIMG], (SDL_Point){3, 18}, 0.0f);
		draw_image(screen, &tex[show_idx], tex[show_idx].pos, shade);
	}
	else
	{
		draw_image(screen, &tex[show_idx], tex[show_idx].pos, 0.0f);
	}
	// lower menu option
	if(mouse_in_region(screen, 8, 23, 23, 27))
	{
		draw_image(screen, &tex[SelectIMG], (SDL_Point){3, 24}, 0.0f);
		draw_image(screen, &tex[show_idx+1], (SDL_Point){8, 23}, shade);
	}
	else
	{
		draw_image(screen, &tex[show_idx+1], (SDL_Point){8, 23}, 0.0f);
	}
	
	// scroll buttons
    if(menu->show_option > 0)
    {
    	if(mouse_in_region(screen, 26, 28, 16, 17))
    		draw_image(screen, &tex[ScrollUpIMG], tex[ScrollUpIMG].pos, shade);
		else
			draw_image(screen, &tex[ScrollUpIMG], tex[ScrollUpIMG].pos, 0.0f);
	}
	if(menu->show_option < menu->options - 2)
    {
    	if(mouse_in_region(screen, 26, 28, 27, 28))
    		draw_image(screen, &tex[ScrollDownIMG], tex[ScrollDownIMG].pos, shade);
		else
			draw_image(screen, &tex[ScrollDownIMG], tex[ScrollDownIMG].pos, 0.0f);
	}
}
void menu_scroll(Menu *menu, int direction)
{
	menu->show_option += direction;
	
	if(menu->show_option > menu->options-2)
		menu->show_option = menu->options-2;
		
	if(menu->show_option < 0)
		menu->show_option = 0;
}
int menu_mouse_pressed(Menu* menu, Screen* screen, Uint8 mouse_button)
{
	SDL_Point mouse_pos = get_mouse_pos(screen);
	
	//printf("%i %i\n", mouse_pos.x, mouse_pos.y);
	
	// menu options
	if(mouse_in_region(screen, 8, 23, 17, 21) || mouse_in_region(screen, 8, 23, 23, 27))
	{
		switch(menu->show_option + mouse_in_region(screen, 8, 23, 23, 27))
		{
		case PlayOption:
			return 1;
		case ScoreOption:
			return 2;
		case QuitOption:
			return 3;
		default:
			return 0;
		}
	}
	// menu scroll
	if(menu->show_option > 0)
	{
		if(mouse_in_region(screen, 26, 28, 16, 17))
		{
			menu_scroll(menu, -1);
		}
	}
	if(menu->show_option < menu->options-2)
	{
		if(mouse_in_region(screen, 26, 28, 27, 28))
		{
			menu_scroll(menu, 1);
		}
	}
	
	return 0;
}
