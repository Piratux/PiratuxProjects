#include "Textures.h"

void push_texture(Texture* tex, int idx, const char* path, SDL_Point pos)
{
	tex[idx].image = IMG_Load(path);
	tex[idx].pos = pos;
	if(!tex[idx].image)
	{
		printf("IMG_Load: %i %s\n", idx, IMG_GetError());
		// handle error
	}
}
Texture* parse_textures()
{
	Texture* tex = (Texture*)malloc(20 * sizeof(Texture));
	int idx = 0;
	push_texture(tex, idx++, "Assets/Menu/Menu.png", (SDL_Point){0, 0});
	push_texture(tex, idx++, "Assets/Menu/Select.png", (SDL_Point){3, 18});
	push_texture(tex, idx++, "Assets/Menu/ScrollUp.png", (SDL_Point){26, 16});
	push_texture(tex, idx++, "Assets/Menu/ScrollDown.png", (SDL_Point){26, 27});
	push_texture(tex, idx++, "Assets/Menu/Play.png", (SDL_Point){8, 17});
	push_texture(tex, idx++, "Assets/Menu/Score.png", (SDL_Point){8, 17});
	push_texture(tex, idx++, "Assets/Menu/Save.png", (SDL_Point){8, 17});
	push_texture(tex, idx++, "Assets/Menu/Load.png", (SDL_Point){8, 17});
	push_texture(tex, idx++, "Assets/Menu/Quit.png", (SDL_Point){8, 17});
	push_texture(tex, idx++, "Assets/Menu/ScorePage.png", (SDL_Point){0, 0});
	push_texture(tex, idx++, "Assets/Game/Game.png", (SDL_Point){0, 0});
	push_texture(tex, idx++, "Assets/Game/Go.png", (SDL_Point){16, 8});
	push_texture(tex, idx++, "Assets/Game/Win.png", (SDL_Point){16, 8});
	push_texture(tex, idx++, "Assets/Game/Lose.png", (SDL_Point){16, 8});
	push_texture(tex, idx++, "Assets/Game/Numbers.png", (SDL_Point){0, 0});
	push_texture(tex, idx++, "Assets/Game/New.png", (SDL_Point){15, 24});
	push_texture(tex, idx++, "Assets/Game/Add.png", (SDL_Point){11, 26});	
	push_texture(tex, idx++, "Assets/Game/Back.png", (SDL_Point){15, 1});
	
	for(int i = 0; i < idx; i++)
	{
		if(!tex[i].image)
		{
			return NULL;
		}
	}
	return tex;
}
