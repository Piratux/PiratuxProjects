#include "Libraries.h"
#include "Menu.h"
#include "GamePlay.h"
#include "Textures.h"
#include "Screen.h"
#include "Score.h"

// Adjustable
const int PIXEL_SIZE = 25;

// Not adjustable(game is made with this resolution in mind)
const int HEIGHT = 30;
const int WIDTH = 30;

enum States
{
	MenuState, GameState, ScoreState, QuitState
};
int main(int argc, char** argv)
{	
    srand (time(NULL));

    SDL_Init(SDL_INIT_VIDEO);
	
    SDL_Window* window = SDL_CreateWindow("Master Mind", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                                          WIDTH * PIXEL_SIZE, HEIGHT * PIXEL_SIZE, SDL_WINDOW_SHOWN | SDL_WINDOW_OPENGL);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    
    Screen screen = create_screen(PIXEL_SIZE);
    
    Texture* textures = parse_textures();
    
    Menu menu;
    init_menu(&menu);
    
    Game game;
    init_game(&game);
    
    int state = MenuState;
    
    bool running = true;
    Uint32 previous_time = 0, curr_time = 0, delta;
    SDL_Event event;
    while (running)
    {
    	curr_time = SDL_GetTicks();
    	delta = curr_time - previous_time;
    	previous_time = curr_time;
    	
        // check for various events (keyboard, mouse, touch, close)
        while (SDL_PollEvent(&event))
        {
            if (event.type == SDL_QUIT)
            {
                running = false;
            }
            if(event.type == SDL_KEYDOWN)
			{
				const char* key = SDL_GetKeyName(event.key.keysym.sym);
				if (strcmp(key, "Escape") == 0)
	    		{
	    			state = MenuState;
				}
			}
			if(event.type == SDL_MOUSEBUTTONDOWN && (event.button.button == SDL_BUTTON_LEFT || event.button.button == SDL_BUTTON_RIGHT))
			{
				switch(state)
				{
				case MenuState:
					state = menu_mouse_pressed(&menu, &screen, event.button.button);
					if(state == QuitState)
						running = false;
					break;
				case GameState:
					state = game_mouse_pressed(&game, &screen, event.button.button);
					break;
				case ScoreState:
					state = score_mouse_pressed(&game, &screen, event.button.button);
					break;
				}
			}
			if(event.type == SDL_MOUSEWHEEL)
			{
				switch(state)
				{
				case MenuState:
					menu_scroll(&menu, -event.wheel.y);
					break;
				}
			}
        }
    	
    	switch(state)
    	{
    	case MenuState:
    		draw_menu(&screen, textures, &menu);
    		break;
    	case GameState:
    		draw_game(&screen, textures, &game, delta);
    		break;
    	case ScoreState:
    		draw_score(&screen, textures, &game);
    		break;
		}
		
    	SDL_RenderClear(renderer);
        update_screen(renderer, &screen);
    	SDL_RenderPresent(renderer);
    }
    
    free(textures);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}

