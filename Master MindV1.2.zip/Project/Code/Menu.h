#pragma once

#include "Libraries.h"

#include "Screen.h"
#include "Textures.h"

typedef struct Menu
{
	int options;
	int show_option;
	int texture_enum_offset;
}Menu;
enum MenuOptions
{
	PlayOption, ScoreOption, SaveOption, LoadOption, QuitOption
};

void init_menu(Menu* menu);
void draw_menu(Screen* screen, Texture* tex, Menu* menu);
void menu_scroll(Menu *menu, int direction);
int menu_select(Menu* menu);
int menu_mouse_pressed(Menu* menu, Screen* screen, Uint8 mouse_button);
void menu_mouse_moved(Menu* menu, Screen* screen, Uint8 mouse_button);
