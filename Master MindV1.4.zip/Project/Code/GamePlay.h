#pragma once

#include "Libraries.h"

#include "Screen.h"
#include "Textures.h"

typedef struct Game
{
	SDL_Color colours[15];
	int secret_code[4];
	int evaluation[12][4];
	int guesses[12][4];
	int curr_guess[4];
	int total_guesses;
	int state;
	time_t scores[4];
	int total_scores;
	time_t second;
	time_t timer;
}Game;

enum GameStates
{
	GoState, WinState, LoseState
};
enum Colours
{
	White, Yellow, Red, Green, Blue, Orange, Gray, Pink, Black
};

void init_game(Game* game);
void reset_game(Game* game);
void draw_game(Screen* screen, Texture* tex, Game* game, Uint32 delta);
void draw_timer(Screen* screen, Texture* tex, Game* game);
void draw_guesses(Game* game, Screen* screen);
int game_mouse_pressed(Game* game, Screen* screen, Uint8 mouse_button);
void generate_code(Game* game);
void change_guess(Game* game, Screen* screen, int idx, int direction);
void add_guess(Game* game, Screen* screen);
void evaluate_guess(Game* game, Screen* screen);
void add_score(Game* game);
