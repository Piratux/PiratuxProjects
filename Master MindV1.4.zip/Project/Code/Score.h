#pragma once

#include "Libraries.h"

#include "Screen.h"
#include "Textures.h"
#include "GamePlay.h"

void draw_score(Screen* screen, Texture* tex, Game* game);
int score_mouse_pressed(Game* game, Screen* screen, Uint8 mouse_button);

